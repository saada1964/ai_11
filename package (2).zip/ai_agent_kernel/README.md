# نواة وكيل الذكاء الاصطناعي الديناميكي
## Dynamic AI Agent Kernel

![Python](https://img.shields.io/badge/python-3.11+-blue.svg)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15+-blue.svg)
![Redis](https://img.shields.io/badge/Redis-7+-red.svg)
![Docker](https://img.shields.io/badge/Docker-ready-blue.svg)

نواة وكيل ذكاء اصطناعي ديناميكية وقابلة للتوسع تدعم تعدد المستخدمين مع نظام إدارة تكاليف متقدم.

---

## المميزات الرئيسية

### 🔧 **بنية ديناميكية بالكامل**
- **نظام النماذج الديناميكي**: تكوين جميع نماذج اللغة من قاعدة البيانات
- **نظام الأدوات الديناميكي**: إضافة وإدارة الأدوات من قاعدة البيانات
- **الذاكرة متعددة الطبقات**: ذاكرة طويلة ومتوسطة وقصيرة المدى

### 🚀 **ميزات متقدمة**
- **البث المباشر**: استجابات فورية للمستخدمين
- **نظام المحاسبة الدقيق**: تتبع التكاليف لكل عملية
- **معمارية قابلة للتوسع**: دعم Docker و Celery
- **واجهة API شاملة**: RESTful API مع وثائق تلقائية

### 🧠 **التفكير الذاتي والتصحيح الذاتي (جديد)**
- **نظام النقد المستقل**: تحليل وتقييم خطط التنفيذ بالذكاء الاصطناعي
- **حلقة التصحيح الذاتي**: تحسين تلقائي للخطط مع تسجيل النقاط
- **مراقبة الجودة**: مقاييس جودة التنفيذ في الوقت الفعلي والتحقق من الصحة
- **تحسين الخطة**: تجميع الخطوات تلقائياً وتحسين الكفاءة
- **كشف الأخطاء**: التحقق من التبعيات الدائرية ومنطق الخطة

### 💾 **الذاكرة الديناميكية (جديد)**
- **البحث المتجهي للذاكرة**: استرجاع ذكي للذكريات باستخدام التشابه الدلالي
- **تحسين السياق**: إدماج الذكريات ذات الصلة تلقائياً في الخطط
- **نماذج التضمين**: استخدام تقنيات متقدمة لتوليد التمثيلات المتجهية
- **تحليل الأنماط**: تحليل أنماط استخدام الذاكرة وتقديم التوصيات
- **تقييم الصلة**: نظام ذكي لتقييم مدى ملاءمة الذكريات للطلب الحالي

### 🏗️ **النظام الهرمي للأدوات (جديد)**
- **وكلاء فرعيون متخصصون**: وكلاء ذكية لمجالات محددة (بحث، ويب، بيانات)
- **أدوات هرمية معقدة**: أدوات متقدمة مدعومة بالوكلاء الفرعيين
- **تنسيق متعدد الوكلاء**: تنسيق ذكي بين عدة وكلاء فرعيين
- **تحسين اختيار الأدوات**: اختيار تلقائي للأدوات الأنسب للمهمة
- **إدارة المهام المعقدة**: حل مشاكل معقدة بتفكيكها إلى مهام فرعية

### 🎨 **واجهة المستخدم التفاعلية (جديد)**
- **مكونات UI ديناميكية**: إرجاع مكونات واجهة مستخدم بدلاً من النص فقط
- **أنواع متعددة من النتائج**: جداول، مخططات، خرائط، صور، كود، نماذج تفاعلية
- **تحليل تلقائي للنتائج**: تحويل البيانات تلقائياً إلى مكونات UI مناسبة
- **استجابات محسنة**: تجربة مستخدم أكثر ثراءً وتفاعلاً
- **نظام إدارة المكونات**: إدارة وتتبع جميع مكونات واجهة المستخدم

### 📈 **المراقبة المتقدمة (جديد)**
- **Distributed Tracing**: تتبع شامل للعمليات عبر جميع مكونات النظام
- **OpenTelemetry Integration**: دمج كامل مع معايير المراقبة الصناعية
- **Metrics Collection**: جمع وتحليل مقاييس الأداء والجودة في الوقت الفعلي
- **Performance Monitoring**: مراقبة الأداء مع تنبيهات عتبة الأخطاء
- **Error Tracking**: تتبع شامل للأخطاء مع السياق التفصيلي
- **System Health Dashboard**: لوحة معلومات شاملة لحالة النظام
- **Real-time Analytics**: تحليلات فورية للاتجاهات والأنماط

### 📊 **التقنيات المستخدمة**
- **Backend**: FastAPI + Python 3.11+
- **قاعدة البيانات**: PostgreSQL + pgvector
- **التخزين المؤقت**: Redis
- **الطوابير**: Celery + Redis
- **الحاويات**: Docker + docker-compose

---

## التثبيت السريع

### متطلبات النظام
- Docker و Docker Compose
- Python 3.11+
- Git

### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd ai_agent_kernel
```

### 2. إعداد متغيرات البيئة
```bash
cp .env.example .env
# قم بتعديل .env وإضافة مفاتيح API الخاصة بك
```

### 3. تشغيل الخدمات
```bash
# تشغيل جميع الخدمات
docker-compose up -d

# أو تشغيل خدمة واحدة فقط
docker-compose up postgres redis
```

### 4. تشغيل التطبيق
```bash
# في terminal جديد
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 5. تشغيل العمال (اختياري)
```bash
# في terminal آخر
celery -A workers.celery worker --loglevel=info
```

---

## وثائق API

بعد تشغيل التطبيق، يمكنك الوصول إلى:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

---

## واجهات API الأساسية

### 1. استدعاء الوكيل الرئيسي

#### نقطة النهاية: `POST /agent/invoke`
```bash
curl -X POST "http://localhost:8000/agent/invoke" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "ابحث عن معلومات حول الذكاء الاصطناعي",
       "user_id": 1,
       "conversation_id": null
     }'
```

#### نقطة النهاية للبث المباشر: `POST /agent/invoke-stream`
```bash
curl -X POST "http://localhost:8000/agent/invoke-stream" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "احسب 2+2",
       "user_id": 1
     }'
```

### 2. إدارة النماذج

#### الحصول على النماذج المتاحة
```bash
curl "http://localhost:8000/models/active"
```

#### إضافة نموذج جديد
```bash
curl -X POST "http://localhost:8000/models/" \\
     -H "Content-Type: application/json" \\
     -d '{
       "name": "gpt-4",
       "provider": "OpenAI",
       "api_endpoint": "https://api.openai.com/v1/chat/completions",
       "api_standard": "openai",
       "price_per_million_tokens": 30.0,
       "role": "direct_answer",
       "max_tokens": 8000,
       "temperature": 0.7
     }'
```

### 3. إدارة الأدوات

#### الحصول على الأدوات المتاحة
```bash
curl "http://localhost:8000/tools/active"
```

#### اختبار أداة
```bash
curl -X POST "http://localhost:8000/tools/1/test" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "Python programming"
     }'
```

### 4. إدارة المحادثات

#### الحصول على محادثات المستخدم
```bash
curl "http://localhost:8000/conversations/?user_id=1&limit=10"
```

#### الحصول على رسائل محادثة
```bash
curl "http://localhost:8000/conversations/1/messages"
```

---

## الهيكلية

```
ai_agent_kernel/
├── api/                    # FastAPI endpoints
│   └── endpoints/
├── config/                 # إعدادات التطبيق
├── core/                   # المكونات الأساسية
│   ├── llm_client.py      # نظام النماذج الديناميكي
│   ├── tools.py           # نظام الأدوات
│   ├── planner.py         # المخطط الذكي
│   ├── executor.py        # المنفذ
│   ├── accounting.py      # نظام المحاسبة
│   └── orchestrator.py    # المنسق الرئيسي
├── database/               # إعدادات قاعدة البيانات
├── models/                 # نماذج SQLAlchemy
├── schemas/                # نماذج Pydantic
├── workers/                # مهام Celery
├── files/                  # معالجة الملفات
├── main.py                # نقطة الدخول الرئيسية
├── requirements.txt       # متطلبات Python
├── Dockerfile            # تكوين Docker
└── docker-compose.yml    # تكوين Docker Compose
```

---

## المكونات الأساسية

### 1. المنسق (Orchestrator)
يدير دورة حياة الطلب الكاملة:
- جلب الذاكرة والسياق
- إنشاء خطة عمل
- تنفيذ الخطة
- إعداد الاستجابة النهائية

### 2. المخطط (Planner)
يحول طلبات اللغة الطبيعية إلى خطط عمل:
- تحليل نية المستخدم
- إنشاء رسم بياني للاعتماديات
- تحديد الأدوات المطلوبة

### 3. المنفذ (Executor)
ينفذ خطوات الخطة:
- إدارة الاعتماديات
- تنفيذ الأدوات المتزامنة وغير المتزامنة
- تجميع النتائج

### 4. نظام الأدوات
أدوات تقليدية:
- **web_search_serper**: بحث ويب سريع
- **wikipedia_search**: بحث ذكي في ويكيبيديا
- **advanced_calculator**: آلة حاسبة آمنة
- **search_user_documents**: بحث في المستندات (قريباً)

**أدوات هرمية متقدمة:**
- **research_workflow**: سير عمل بحث شامل مدعوم بالوكلاء
- **web_analysis**: تحليل محتوى ويب متقدم
- **data_processing**: معالجة وتحليل البيانات
- **complex_executor**: منفذ المهام المعقدة متعددة الخطوات

### 5. نظام المحاسبة
- حساب تكلفة كل طلب
- إدارة أرصدة المستخدمين
- تتبع الاستخدام
- تقارير مفصلة

### 6. نظام واجهة المستخدم التفاعلية
مكونات UI ديناميكية:
- **مكونات نصية**: نصوص منسقة، كود مميز، تنبيهات
- **مكونات البيانات**: جداول تفاعلية، مخططات، إحصائيات
- **مكونات الوسائط**: صور، خرائط، مقاطع فيديو
- **مكونات تفاعلية**: نماذج، بطاقات، قوائم
- **تحليل تلقائي**: تحويل البيانات إلى مكونات UI مناسبة

---

## الاستخدام

### مثال: طلب بسيط
```bash
curl -X POST "http://localhost:8000/agent/invoke" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "ما هو الذكاء الاصطناعي؟",
       "user_id": 1
     }'
```

### مثال: طلب معقد (بحث + حساب)
```bash
curl -X POST "http://localhost:8000/agent/invoke" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "ابحث عن أحدث تطورات الذكاء الاصطناعي ثم احسب 25*4",
       "user_id": 1
     }'
```

### مثال: طلب بالبث المباشر
```bash
curl -X POST "http://localhost:8000/agent/invoke-stream" \\
     -H "Content-Type: application/json" \\
     -N \\
     -d '{
       "query": "اشرح لي مفهوم التعلم الآلي بالتفصيل",
       "user_id": 1
     }'
```

---

## المراقبة المتقدمة والتحليلات

### مقدمة في نظام المراقبة
يوفر النظام مراقبة متقدمة شاملة مع OpenTelemetry وdistributed tracing لتحليل الأداء والأخطاء في الوقت الفعلي.

### ميزات المراقبة الرئيسية

#### 📊 **جمع المقاييس (Metrics Collection)**
- **Counters**: عدد الطلبات، الأخطاء، النجاحات
- **Gauges**: استخدام الذاكرة، وقت الاستجابة، درجات الجودة
- **Histograms**: توزيع أوقات التنفيذ، أحجام البيانات

```python
from core.observability import observability_manager, MetricType

# تسجيل مقاييس مخصصة
observability_manager.record_metric(
    "custom.counter", 1.0, 
    MetricType.COUNTER,
    {"component": "user_interface"}
)

observability_manager.record_metric(
    "performance.latency", 150.0,
    MetricType.GAUGE,
    {"endpoint": "/agent/invoke"}
)
```

#### 🔍 **Distributed Tracing**
تتبع العمليات عبر جميع مكونات النظام مع مستويات مفصلة:

```python
from core.observability import observe_operation, TraceLevel

# تتبع عملية كاملة
async with observability_manager.trace_operation(
    "complete_request",
    {"user_id": "123", "query_type": "complex"},
    TraceLevel.HIGH
):
    # تنفيذ العملية
    await process_request()

# تتبع مراحل فرعية
async with observability_manager.trace_operation(
    "data_processing",
    level=TraceLevel.MEDIUM
):
    await process_data()
```

#### 📈 **مراقبة الأداء**
- **تنبيهات عتبة الأخطاء**: تنبيهات عند تجاوز حدود الأداء
- **تحليل الاتجاهات**: تحليل الأداء عبر الزمن
- **تقارير الجودة**: تقارير مفصلة عن جودة العمليات

```python
# الحصول على إحصائيات الأداء
perf_stats = observability_manager.get_performance_metrics()
print(f"متوسط وقت الاستجابة: {perf_stats['summary']['average_duration']}")

# الحصول على حالة النظام
system_status = observability_manager.get_system_status()
print(f"صحة النظام: {system_status['system_health']}")
```

#### 🚨 **تتبع الأخطاء**
- **خطأ مفصل**: السياق الكامل للخطأ مع تتبع المشكلة
- **تصنيف الأخطاء**: تصنيف الأخطاء حسب النوع والمصدر
- **إحصائيات الأخطاء**: تحليل أخطاء النظام عبر الزمن

### تكامل المراقبة في المكونات

#### 🎯 **المنسق (Orchestrator)**
- تتبع دورة حياة الطلب الكاملة
- مقاييس الأداء لكل مرحلة
- مقاييس نجاح/فشل المعالجة

#### 📝 **المخطط (Planner)**
- تتبع عمليات التخطيط والتصحيح الذاتي
- مقاييس تحسين الخطط
- إحصائيات استخدام الذاكرة الديناميكية

#### ⚙️ **المنفذ (Executor)**
- تتبع تنفيذ كل خطوة في الخطة
- مراقبة الأداء لكل أداة
- مقاييس جودة التنفيذ

### استخراج وتحليل البيانات

#### 📤 **تصدير المقاييس**
```python
# تصدير جميع المقاييس
metrics_export = observability_manager.export_metrics()
print(f"إجمالي المقاييس: {metrics_export['total_count']}")

# تصدير مقاييس محددة
filtered_metrics = observability_manager.get_metrics_by_type(MetricType.COUNTER)
```

#### 📋 **تتبع الأداء**
```python
# الحصول على تقرير أداء مفصل
performance_report = observability_manager.get_performance_report()
print(f"أهم 5 عمليات بطيئة:")
for operation in performance_report['slowest_operations']:
    print(f"- {operation['name']}: {operation['duration']:.2f}s")
```

### تشغيل اختبارات المراقبة
```bash
# تشغيل اختبارات المراقبة المتقدمة
python test_observability.py

# اختبار التكامل مع المكونات
python -m pytest test_observability.py::TestObservabilityIntegration -v

# اختبار المراقبة العامة
python -m pytest test_observability.py::TestObservabilitySystem::test_system_status -v
```

### مثال على تقرير المراقبة
```json
{
  "system_health": "healthy",
  "metrics": {
    "total_count": 156,
    "counters": {
      "requests.total": 45,
      "requests.success": 42,
      "requests.error": 3
    },
    "gauges": {
      "memory.usage": 85.2,
      "cpu.usage": 23.1
    }
  },
  "traces": {
    "total_count": 89,
    "avg_duration": 0.234,
    "error_rate": 0.067
  },
  "performance": {
    "slowest_operations": [
      {"name": "agent.planning", "duration": 1.23},
      {"name": "tool.execution", "duration": 0.89}
    ]
  }
}
```

---

## الاختبار

### تشغيل الاختبارات
```bash
# تثبيت متطلبات التطوير
pip install -r requirements.txt

# تشغيل الاختبارات
pytest tests/ -v

# اختبار تغطية الكود
pytest tests/ --cov=ai_agent_kernel --cov-report=html
```

### اختبار نقاط النهاية
```bash
# اختبار الصحة العامة
curl http://localhost:8000/health

# اختبار مفصل
curl http://localhost:8000/health/detailed

# اختبار النماذج
curl "http://localhost:8000/models/"

# اختبار الأدوات
curl "http://localhost:8000/tools/"
```

---

## النشر

### إنتاج Docker
```bash
# بناء صورة الإنتاج
docker build -t ai-agent-kernel:latest .

# تشغيل في وضع الإنتاج
docker-compose --profile production up -d
```

### متغيرات البيئة للإنتاج
```bash
ENVIRONMENT=production
DEBUG=False
SECRET_KEY=your-secret-key-here
DATABASE_URL=postgresql+asyncpg://user:pass@postgres:5432/ai_agent_kernel
```

## الاختبار

### تشغيل الاختبارات الأساسية
```bash
# تشغيل اختبار النظام الكامل
python test_system.py

# اختبار نظام التفكير الذاتي الجديد
python test_self_correction.py

# اختبار نظام الذاكرة الديناميكية الجديد
python test_dynamic_memory.py

# اختبار النظام الهرمي للأدوات الجديد
python test_hierarchical_tools.py

# اختبار واجهة المستخدم التفاعلية الجديدة
python test_ui_components.py

# تشغيل اختبار محدد
python -m pytest tests/test_planner.py -v
```

### اختبارات التفكير الذاتي والتصحيح الذاتي
تم إضافة مجموعة اختبارات شاملة للنظام الجديد:

### اختبارات الذاكرة الديناميكية
تم إضافة مجموعة اختبارات شاملة لنظام الذاكرة:

- **اختبار نواة الذاكرة**: التحقق من وظائف الذاكرة الأساسية والإعدادات
- **توليد التضمينات**: اختبار توليد وحفظ التمثيلات المتجهية
- **استرجاع الذاكرة**: اختبار البحث المتجهي وتصنيف الصلة
- **تحسين الخطط**: اختبار إدماج الذكريات في الخطط
- **تحليل الأنماط**: اختبار تحليل أنماط الاستخدام والتوصيات
- **حالات الحد**: اختبار المعالجة للحالات الاستثنائية والحدود

### النتائج المتوقعة للذاكرة الديناميكية
```
============================================================
DYNAMIC MEMORY TEST SUITE SUMMARY
============================================================
Total Tests: 20
✅ Passed: 20
❌ Failed: 0
Success Rate: 100.0%
🎉 ALL TESTS PASSED - Dynamic memory system is working correctly!
============================================================
```

- **اختبار مكون النقد**: التحقق من وظائف النقد والتحليل
- **تقييم جودة الخطة**: اختبار حساب نقاط الجودة
- **تكامل التصحيح الذاتي**: اختبار الحلقة الكاملة للتصحيح
- **مراقبة الجودة**: اختبار مقاييس الجودة والتنفيذ
- **حالات الحد**: اختبار المعالجة للحالات الاستثنائية

### النتائج المتوقعة
```
============================================================
SELF-CORRECTION TEST SUITE SUMMARY
============================================================
Total Tests: 15
✅ Passed: 15
❌ Failed: 0
Success Rate: 100.0%
🎉 ALL TESTS PASSED - Self-correction system is working correctly!
============================================================
```

---

## المساهمة

1. Fork المشروع
2. إنشاء branch جديد للميزة
3. Commit التغييرات
4. Push للـ branch
5. إنشاء Pull Request

---

## الترخيص

MIT License - راجع ملف LICENSE للتفاصيل.

---

## الدعم

- **الوثائق**: http://localhost:8000/docs
- **Issues**: https://github.com/your-repo/issues
- **Email**: support@example.com

---

## شكر وتقدير

هذا المشروع مبني على أفضل الممارسات في تطوير البرمجيات والتطوير المدفوع بالاختبار.

**تم التطوير بواسطة**: MiniMax Agent
**التاريخ**: نوفمبر 2025