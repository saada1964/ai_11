# نظام الشحن والدفع الإلكتروني - AI Agent Kernel

## 📋 نظرة عامة

تم تطوير نظام شامل لشحن الرصيد والدفع الإلكتروني لنظام AI Agent Kernel. يدعم النظام أكواد الخصم والدفع الإلكتروني عبر Stripe و Plisio و PayPal، مع إمكانيات متقدمة لإدارة الاشتراكات والمعاملات.

## 🚀 المميزات الرئيسية

### 1. نظام أكواد الشحن
- ✅ إنشاء أكواد شحن مخصصة
- ✅ أكواد بحد استخدام محدود أو غير محدود
- ✅ أكواد بخصم أو بدون خصم
- ✅ أكواد بتاريخ انتهاء صلاحية
- ✅ أكواد ترحيبية وبونصات

### 2. أنظمة الدفع الإلكتروني
- 💳 **Stripe**: بطاقات ائتمانية (Visa, Mastercard, Amex)
- 💰 **Plisio**: عملات رقمية (BTC, ETH, LTC, USDT)
- 🔵 **PayPal**: محافظ إلكترونية

### 3. إدارة المعاملات
- 📊 تتبع جميع المعاملات
- 💰 أنواع مختلفة: purchase, credit_code, topup, refund
- ⏰ حالة المعاملة: pending, completed, failed, refunded

### 4. نظام الاشتراكات
- 📅 اشتراكات شهرية
- 🔄 تجديد تلقائي
- 💳 ربط بطاقات الدفع

## 🏗️ هيكل قاعدة البيانات

### الجداول الجديدة:
1. **credit_codes** - أكواد الشحن
2. **credit_transactions** - معاملات الشحن
3. **payment_methods** - طرق الدفع
4. **payment_records** - سجل الدفعات
5. **subscriptions** - الاشتراكات

### الجداول المحدثة:
- **users** - إضافة رصيد (balance)

## 📁 ملفات النظام

### النماذج (Models)
- `/models/credit_models.py` - نماذج نظام الشحن
- `/models/__init__.py` - تحديث لاستيراد النماذج الجديدة

### الخدمات (Services)
- `/services/credit_service.py` - خدمة الشحن والدفع
  - `CreditService` - إدارة أكواد الشحن
  - `PaymentService` - إدارة عمليات الدفع

### المخططات (Schemas)
- `/schemas/credit_schemas.py` - مخططات البيانات

### واجهات برمجة التطبيقات (APIs)
- `/api/credit_api.py` - نقاط النهاية للـ APIs

### Migration Scripts
- `/migrations/sqlite_credit_migration.py` - إنشاء قاعدة البيانات SQLite
- `/migrations/credit_migration.py` - Migration PostgreSQL

### الاختبارات
- `/test_credit_simple.py` - اختبار بسيط
- `/test_credit_system.py` - اختبارات شاملة

## 🛠️ التثبيت والإعداد

### 1. تثبيت المكتبات المطلوبة
```bash
pip install sqlalchemy psycopg2-binary python-dotenv pydantic-settings pytest
```

### 2. إنشاء قاعدة البيانات
```bash
cd ai_agent_kernel
python migrations/sqlite_credit_migration.py
```

### 3. تشغيل الاختبارات
```bash
python test_credit_simple.py
```

## 🎯 أكواد الشحن المتاحة

### الأكواد التجريبية:
| الكود | الاسم | المبلغ | الاستخدامات | ينتهي |
|-------|-------|--------|-------------|-------|
| WELCOME100 | كود ترحيبي | 1000 وحدة | 100/100 | 2025-12-01 |
| BONUS500 | بونص 500 وحدة | 500 وحدة | 0/50 | 2025-12-31 |
| RESEARCH20 | خصم 20% على البحث | 200 وحدة | 0/25 | 2025-12-16 |
| VIP1000 | كود VIP | 1000 وحدة | 0/10 | 2026-01-30 |

## 🔗 واجهات برمجة التطبيقات (APIs)

### إدارة أكواد الشحن
```http
POST /credit/codes
# إنشاء كود شحن جديد

POST /credit/codes/redeem
# استخدام كود شحن

GET /credit/codes
# قائمة أكواد الشحن

GET /credit/codes/{code_id}
# تفاصيل كود شحن
```

### المعاملات والإحصائيات
```http
GET /credit/statistics
# إحصائيات النظام

GET /credit/transactions
# معاملات المستخدم
```

### الدفع الإلكتروني
```http
POST /credit/payments/initialize
# بدء عملية دفع

POST /credit/payments/complete
# إتمام عملية دفع

GET /credit/payment-methods
# طرق الدفع المتاحة
```

### إدارة الرصيد
```http
GET /credit/balance/{user_id}
# رصيد المستخدم

POST /credit/balance/topup
# شحن الرصيد (للمديرين)
```

### الاشتراكات
```http
POST /credit/subscriptions
# إنشاء اشتراك

GET /credit/subscriptions/{user_id}
# اشتراكات المستخدم
```

## 📊 أمثلة على الاستخدام

### 1. استخدام كود شحن
```python
from services.credit_service import credit_service

result = credit_service.redeem_credit_code(
    db=session,
    code="WELCOME100",
    user_id=1
)

if result["success"]:
    print(f"تم شحن {result['data']['amount']} وحدة")
    print(f"الرصيد الجديد: {result['data']['new_balance']}")
```

### 2. بدء عملية دفع
```python
from services.credit_service import payment_service

result = payment_service.initialize_payment(
    db=session,
    user_id=1,
    amount_usd=50.0,
    payment_method="stripe"
)

if result["success"]:
    print(f"معرف المعاملة: {result['data']['transaction_id']}")
    print(f"المبلغ: ${result['data']['amount_usd']}")
```

### 3. إتمام عملية دفع
```python
result = payment_service.complete_payment(
    db=session,
    payment_record_id=123,
    external_payment_id="pi_123456",
    status="succeeded"
)
```

## 🔧 الإعدادات المطلوبة

### متغيرات البيئة (.env)
```env
# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/ai_agent_kernel
DATABASE_URL_SYNC=postgresql://user:password@localhost:5432/ai_agent_kernel

# API Keys (للتكامل مع Stripe/Plisio)
STRIPE_API_KEY=sk_test_...
PLISIO_API_KEY=your_plisio_key

# Security
SECRET_KEY=your-secret-key-here
```

## 🧪 الاختبار

### اختبار النظام
```bash
# اختبار بسيط
python test_credit_simple.py

# اختبار شامل مع pytest
pytest test_credit_system.py -v
```

### النتائج المتوقعة
```
✅ عدد المستخدمين: 2
✅ عدد أكواد الشحن: 4
✅ عدد طرق الدفع: 3
✅ عدد المعاملات: 2
✅ تم اختبار نظام الشحن بنجاح!
```

## 📈 الإحصائيات والمتابعة

### إحصائيات النظام
- عدد الأكواد النشطة/المنتهية
- معدل الاستخدام
- أكثر الأكواد استخداماً
- إجمالي المعاملات

### تقارير المستخدمين
- تاريخ المعاملات
- الأرصدة الحالية
- طرق الدفع المستخدمة
- الاشتراكات النشطة

## 🔒 الأمان والصلاحيات

### مستويات الصلاحيات
- **المستخدمون**: استخدام أكواد الشحن، عرض رصيدهم
- **المديرون**: إنشاء أكواد، شحن أرصدة، إدارة طرق الدفع
- **المشرفون**: إدارة كاملة للنظام

### الأمان
- التحقق من صحة البيانات
- منع استخدام أكواد منتهية الصلاحية
- تسجيل جميع العمليات
- فهارس قاعدة البيانات للأداء

## 🚨 حل المشاكل الشائعة

### خطأ: "كود الشحن غير موجود"
- تأكد من صحة الكود
- تحقق من أن الكود نشط وغير منتهي الصلاحية

### خطأ: "الحد الأقصى للاستخدام"
- تم استخدام الكود الحد الأقصى المسموح
- جرب كود آخر

### خطأ: "طريقة الدفع غير مدعومة"
- تأكد من استخدام طريقة دفع صحيحة
- تحقق من إعدادات النظام

## 🔄 التحديثات المستقبلية

### مخطط التطوير
- [ ] تكامل مع Stripe/Plisio APIs
- [ ] نظام إشعارات الدفع
- [ ] تقارير مالية متقدمة
- [ ] نظام ولاء العملاء
- [ ] تطبيق mobile
- [ ] واجهة ويب إدارية

## 📞 الدعم والتواصل

للحصول على الدعم أو الإبلاغ عن مشاكل:
- راجع ملف الاختبارات
- تحقق من logs النظام
- تواصل مع فريق التطوير

---

**تم التطوير بواسطة**: MiniMax Agent  
**الإصدار**: 1.0.0  
**تاريخ التحديث**: 2025-11-01

🎉 **تم بنجاح إنشاء وتفعيل نظام الشحن والدفع الإلكتروني!**