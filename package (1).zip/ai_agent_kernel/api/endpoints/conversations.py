from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from database.database import get_db
from schemas.schemas import Conversation
from config.logger import logger

router = APIRouter()


@router.get("/", response_model=list[Conversation])
async def get_conversations(
    user_id: int = Query(..., description="Filter by user ID"),
    limit: int = Query(20, ge=1, le=100, description="Number of conversations to return"),
    offset: int = Query(0, ge=0, description="Number of conversations to skip"),
    db: AsyncSession = Depends(get_db)
):
    """Get conversations for a user"""
    try:
        result = await db.execute(
            text("""
                SELECT c.*, u.username 
                FROM conversations c 
                JOIN users u ON c.user_id = u.id 
                WHERE c.user_id = :user_id 
                ORDER BY c.updated_at DESC 
                LIMIT :limit OFFSET :offset
            """),
            {"user_id": user_id, "limit": limit, "offset": offset}
        )
        
        conversations = []
        for row in result.fetchall():
            conversations.append({
                "id": row[0],
                "user_id": row[1],
                "title": row[2],
                "summary": row[3],
                "total_messages": row[4],
                "created_at": row[5].isoformat() if row[5] else None,
                "updated_at": row[6].isoformat() if row[6] else None,
                "username": row[7]  # This is added in the query
            })
        
        return conversations
        
    except Exception as e:
        logger.error(f"Get conversations error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{conversation_id}", response_model=Conversation)
async def get_conversation(
    conversation_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get a specific conversation with messages"""
    try:
        # Get conversation info
        conv_result = await db.execute(
            text("""
                SELECT c.*, u.username 
                FROM conversations c 
                JOIN users u ON c.user_id = u.id 
                WHERE c.id = :conversation_id
            """),
            {"conversation_id": conversation_id}
        )
        
        conversation = conv_result.fetchone()
        if not conversation:
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        # Get message count
        count_result = await db.execute(
            text("SELECT COUNT(*) FROM messages WHERE conversation_id = :conversation_id"),
            {"conversation_id": conversation_id}
        )
        message_count = count_result.scalar()
        
        return {
            "id": conversation[0],
            "user_id": conversation[1],
            "title": conversation[2],
            "summary": conversation[3],
            "total_messages": message_count,
            "created_at": conversation[4].isoformat() if conversation[4] else None,
            "updated_at": conversation[5].isoformat() if conversation[5] else None,
            "username": conversation[6]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get conversation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=Conversation)
async def create_conversation(
    conversation_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """Create a new conversation"""
    try:
        # Validate user exists
        user_result = await db.execute(
            text("SELECT id FROM users WHERE id = :user_id"),
            {"user_id": conversation_data["user_id"]}
        )
        
        if not user_result.fetchone():
            raise HTTPException(status_code=404, detail="User not found")
        
        # Create conversation
        result = await db.execute(
            text("""
                INSERT INTO conversations (user_id, title, summary)
                VALUES (:user_id, :title, :summary)
                RETURNING *
            """),
            {
                "user_id": conversation_data["user_id"],
                "title": conversation_data.get("title", "New Conversation"),
                "summary": conversation_data.get("summary")
            }
        )
        
        row = result.fetchone()
        
        return {
            "id": row[0],
            "user_id": row[1],
            "title": row[2],
            "summary": row[3],
            "total_messages": row[4],
            "created_at": row[5].isoformat() if row[5] else None,
            "updated_at": row[6].isoformat() if row[6] else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create conversation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{conversation_id}", response_model=Conversation)
async def update_conversation(
    conversation_id: int,
    update_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """Update a conversation"""
    try:
        # Check if conversation exists
        existing = await db.execute(
            text("SELECT id FROM conversations WHERE id = :conversation_id"),
            {"conversation_id": conversation_id}
        )
        
        if not existing.fetchone():
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        # Build update query dynamically
        update_fields = []
        params = {"conversation_id": conversation_id}
        
        for field, value in update_data.items():
            if field in ["title", "summary"]:
                update_fields.append(f"{field} = :{field}")
                params[field] = value
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No valid fields to update")
        
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        
        query = f"""
            UPDATE conversations 
            SET {', '.join(update_fields)}
            WHERE id = :conversation_id
            RETURNING *
        """
        
        result = await db.execute(text(query), params)
        row = result.fetchone()
        
        return {
            "id": row[0],
            "user_id": row[1],
            "title": row[2],
            "summary": row[3],
            "total_messages": row[4],
            "created_at": row[5].isoformat() if row[5] else None,
            "updated_at": row[6].isoformat() if row[6] else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update conversation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{conversation_id}")
async def delete_conversation(
    conversation_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Delete a conversation and all its messages"""
    try:
        result = await db.execute(
            text("DELETE FROM conversations WHERE id = :conversation_id RETURNING id"),
            {"conversation_id": conversation_id}
        )
        
        if not result.fetchone():
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        return {"message": "Conversation deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete conversation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{conversation_id}/messages")
async def get_conversation_messages(
    conversation_id: int,
    limit: int = Query(50, ge=1, le=200, description="Number of messages to return"),
    offset: int = Query(0, ge=0, description="Number of messages to skip"),
    db: AsyncSession = Depends(get_db)
):
    """Get messages from a conversation"""
    try:
        # Check if conversation exists
        conv_result = await db.execute(
            text("SELECT id FROM conversations WHERE id = :conversation_id"),
            {"conversation_id": conversation_id}
        )
        
        if not conv_result.fetchone():
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        # Get messages
        result = await db.execute(
            text("""
                SELECT role, content, tokens_used, cost_usd, created_at
                FROM messages 
                WHERE conversation_id = :conversation_id 
                ORDER BY created_at ASC 
                LIMIT :limit OFFSET :offset
            """),
            {"conversation_id": conversation_id, "limit": limit, "offset": offset}
        )
        
        messages = []
        for row in result.fetchall():
            messages.append({
                "role": row[0],
                "content": row[1],
                "tokens_used": row[2],
                "cost_usd": float(row[3]) if row[3] else 0.0,
                "created_at": row[4].isoformat() if row[4] else None
            })
        
        return {
            "conversation_id": conversation_id,
            "messages": messages,
            "total_returned": len(messages),
            "has_more": len(messages) == limit
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get conversation messages error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{conversation_id}/summary")
async def update_conversation_summary(
    conversation_id: int,
    summary_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """Update conversation summary using AI"""
    try:
        from core.llm_client import llm_client
        
        # Check if conversation exists
        conv_result = await db.execute(
            text("SELECT id FROM conversations WHERE id = :conversation_id"),
            {"conversation_id": conversation_id}
        )
        
        if not conv_result.fetchone():
            raise HTTPException(status_code=404, detail="Conversation not found")
        
        # Get recent messages for summary
        messages_result = await db.execute(
            text("""
                SELECT role, content 
                FROM messages 
                WHERE conversation_id = :conversation_id 
                ORDER BY created_at DESC 
                LIMIT 20
            """),
            {"conversation_id": conversation_id}
        )
        
        messages = []
        for row in messages_result.fetchall():
            messages.append({"role": row[0], "content": row[1]})
        
        if not messages:
            raise HTTPException(status_code=400, detail="No messages to summarize")
        
        # Generate summary using AI
        conversation_text = "\n".join([f"{msg['role']}: {msg['content']}" for msg in reversed(messages)])
        
        summary_prompt = f"""Please provide a concise summary of this conversation in 2-3 sentences:

{conversation_text}

Summary:"""
        
        messages_for_ai = [
            {"role": "system", "content": "You are a helpful assistant that summarizes conversations succinctly."},
            {"role": "user", "content": summary_prompt}
        ]
        
        # Use a simple model for summarization
        model_config = {
            "name": "llama-3.1-8b-instant",
            "api_standard": "openai",
            "max_tokens": 200,
            "temperature": 0.3
        }
        
        try:
            response = await llm_client.call_model(model_config, messages_for_ai)
            summary = response["content"].strip()
        except Exception:
            # Fallback summary
            summary = f"Conversation with {len(messages)} messages about various topics."
        
        # Update conversation with summary
        await db.execute(
            text("""
                UPDATE conversations 
                SET summary = :summary, updated_at = CURRENT_TIMESTAMP
                WHERE id = :conversation_id
            """),
            {"conversation_id": conversation_id, "summary": summary}
        )
        
        return {
            "conversation_id": conversation_id,
            "summary": summary,
            "messages_analyzed": len(messages)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update conversation summary error: {e}")
        raise HTTPException(status_code=500, detail=str(e))